#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define MAXCHAR 1000
#define LEN 256
//kelompok 2
//Markus Sjarif 1706036886
//Mohammad Sulthonul Aulia 1706037030
//RPG Game
void map1 ();
void map2 ();
void map3 ();
void map4 ();

void enter(){
printf ("\n%24s[ Tekan Enter Untuk Melanjutkan ]", " ");
getchar ();
fflush (stdin);
}

void delay(int number_of_seconds)
{
    int milli_seconds = 1000 * number_of_seconds;
    clock_t start_time = clock();
    while (clock() < start_time + milli_seconds);
}
void intro(){
printf(R"EOF(
                            ,-,
       ___,---.__          /'|`\          __`.
 /      ___//              `. ,'          ,  , \___      ,---,___
    ,-'    \`    `-.____,-'  |  `-.____,-'    //    `-.
  ,'        |           ~'\     /`~           |        \
|    ,-'   `-.__   _         |        ,    __,-'   `-.    |
|   /          /\_  `   .    |    ,      _/\          \   |
\  |           \ \`-.___ \   |   / ___,-'/ /           |  /
 \  \           | `._   `\\  |  //'   _,' |           /  /
  `-.\         /'  _ `---'' , . ``---' _  `\         /,-'
     ``       /     \    ,='/ \`=.    /     \       ''
             |__   /|\_,--.,-.--,--._/|\   __|
             /  `./  \\`\ |  |  | /,//' \,'  \
            /   /     ||--+--|--+-/-|     \   \
           |   |     /'\_\_\ | /_/_/`\     |   |
            \   \__, \_     `~'     _/ .__/   /
             `-._,-'   `-._______,-'   `-._,-'
)EOF");
printf("\n\n\nSelamat datang di Petualangan Bukaresh!\n");
printf("\nPersiapkan diri anda untuk menjadi warrior sesungguhnya\n");
printf("\nLawan musuh-musuh anda dan tingkatkan kemampuan anda\n\n\n");
enter();
system("cls");
}
struct karakter{
char nama[20];
char wname[20];
int gold;
int hp;
int mhp;
int armor;
int weapon;
int run;
};
struct karakter hero = {"","nebula", 0, 100, 100, 10, 25, 0};
struct karakter priest = {"","bare hand", 0, 60, 60, 7, 8, 0};
void artchar(){
printf(R"EOF(
                              /       /
                           .'<_.-._.'<
                          /           \      .^.
        ._               |  -+- -+-    |    (_|_)
     r- |\                \   /       /      //
   /\ \\  :                \  -=-    /       \\
    `. \\.'           ___.__`..;._.-'---...  //
      ``\\      __.--"        `;'     __   `-.
        /\\.--""      __.,              ""-.  ".
        ;=r    __.---"   | `__    __'   / .'  .'
        '=/\\""           \             .'  .'
            \\             |  __ __    /   |
             \\            |  -- --   //`'`'
              \\           |  -- --  ' | //
               \\          |    .      |//
)EOF");
}
void sambutan(){
printf("======================================================\n");
printf("======================================================\n\n");
printf("Masukkan nama karakter anda: ");
scanf("%s", hero.nama);
system("cls");
printf("\nHALLO %s!\n", hero.nama);
artchar();
printf("\nMusuh-musuh anda sudah tidak sabar menemui anda");
printf("\nPergilah!, bawa kemenangan bersamamu\n\n");
printf("======================================================\n");
printf("======================================================\n\n");
enter();
getchar();
}
struct senjata{
char name [15]; int damage;int price;};
struct senjata w[4] = {
{"Kujang", 200, 400},
{"Keris", 100, 200},
{"Katana", 75, 100},
{"GODSWORD", 1000, 0}};
struct musuh{
char name [15]; int hp; int ap;
int wh; int gold; int run;};
struct musuh e[6] = {
{"joker", 50, 5, 10, 40, 1},
{"iblis", 100, 0, 40, 142, 0},
{"mario", 149, 24, 40, 300, 1},
{"troll", 333, 33, 33, 333, 1},
{"centaur", 500, 4, 75, 1000000, 0},
{"zombie", 0, 0, 0, 0, 1}};
int valid, next, ehp, n, i, damage;

void saveFile(){
FILE *fp;
fp=fopen("save_RPG.txt","w");
//fprintf(fp,"%s %s %d %d %d %d %d %d",hero.nama, hero.wname, hero.gold, hero.hp, hero.mhp, hero.armor, hero.weapon, hero.run);
fprintf(fp,"%s %s %d %d %d %d %d %d %d",hero.nama, hero.wname, hero.gold, hero.hp, hero.mhp, hero.armor, hero.weapon, hero.run, priest.hp);
fclose(fp);
}

void loadFile(){
FILE *fp;
fp=fopen("save_RPG.txt","r");
if(fp == NULL) {
      perror("Error in opening file");
      return(-1);
   }
 while (!feof (fp))
    {
        //fscanf (fp, "%s %s %d %d %d %d %d %d",&hero.nama,&hero.wname,&hero.gold,&hero.hp,&hero.mhp,&hero.armor,&hero.weapon,&hero.run);
      fscanf (fp, "%s %s %d %d %d %d %d %d %d",&hero.nama,&hero.wname,&hero.gold,&hero.hp,&hero.mhp,&hero.armor,&hero.weapon,&hero.run, &priest.hp);
    }
  fclose (fp);
}


void printstat ()
{
printf ("Statistik:\narmor hero:%i\t\t\t\tarmor priest: %i\n", hero.armor,priest.armor);
printf ("Nama Senjata Hero:%s\t\tNama Senjata Priest: %s\n", hero.wname,priest.wname);
printf ("Damage Senjata Hero:%i\t\t\tDamage Senjata Priest: %i\n", hero.weapon,priest.weapon);
printf ("hp hero:%i/%i\t\t\t\thp priest: %i/%i\n", hero.hp, hero.mhp,priest.hp, priest.mhp);
printf ("gold: %i\n", hero.gold);
}

typedef void (*pointer_map) ();
struct tempat {char name [30]; pointer_map map;};
struct tempat p [4] = {
{"gunung", map1},
{"hutan", map2},
{"sungai", map3},
{"kota", map4}};

int damage_calc1 (int c1){
int damage_bruto;int damage_deviation;int damage_netto;
damage_bruto = hero.weapon - e [c1].ap / 4;
srand(rand()%10);
damage_deviation=rand()%5;
damage_netto=damage_deviation+damage_bruto;
return damage_netto;
}
int damage_calc2 (int c2){
int damage_bruto;int damage_deviation;int damage_netto;
damage_bruto = e [c2].wh - hero.armor / 4;
srand(rand()%10);
damage_deviation=rand()%5;
damage_netto=damage_deviation+damage_bruto;
return damage_netto;
}

int damage_calc3 (int c3){
int damage_bruto;int damage_deviation;int damage_netto;
damage_bruto = priest.weapon - e [c3].ap / 4;
srand(rand()%10);
damage_deviation=rand()%5;
damage_netto=damage_deviation+damage_bruto;
return damage_netto;
}

int damage_calc4 (){
int damage_bruto;int damage_deviation;int damage_netto;
damage_bruto = 30;
srand(rand()%10);
damage_deviation=rand()%5;
damage_netto=damage_deviation+damage_bruto;
return damage_netto;
}

int damage_calc5 (int c5){
int damage_bruto;int damage_deviation;int damage_netto;
damage_bruto = (e [c5].wh - hero.armor / 4)/2;
srand(rand()%10);
damage_deviation=rand()%2;
damage_netto=damage_deviation+damage_bruto;
return damage_netto;
}

int damage_calc6 (int c6){
int damage_bruto;int damage_deviation;int damage_netto;
damage_bruto = e [c6].wh - priest.armor / 4;
srand(rand()%10);
damage_deviation=rand()%5;
damage_netto=damage_deviation+damage_bruto;
return damage_netto;
}

void choice (int *n, int max)
{
if (!max) printf ("Silakan pilih tempat yang ingin anda kunjungi?\n");
for (i = 0, *n = 0; i < 4 && !max; i++)
printf ("[%i] %s\n", i + 1, p [i].name);
if (!max) printf("\n\n[5]Save Game\n");
if (!max) printf("[6]Load Game\n");
if (!max) max = 4;
scanf ("%i", n);
if(*n==5)
{saveFile();
printf("Game berhasil disimpan");
delay(1);}
if(*n==6){
loadFile();
printf("Game berhasil diload");
delay(1);
}
fflush (stdin);
if (*n > 0 && *n <= max) valid = 1;
}

void status (int j)
{
system ("cls");
printf ("Anda sedang melawan: %s\n", e [j].name);
printf ("hp musuh:%s%i%shp anda:%s%i/%i\t\thp priest:%s%i/%i\t\n",
"\t", ehp, "\t", "\t", hero.hp, hero.mhp,"\t",priest.hp,priest.mhp);
printf ("armor musuh:%s%i%sarmor anda:%s%i%s%sarmor priest:%s%i\n", "\t", e [j].ap, "\t","\t", hero.armor,"\t","\t","\t", priest.armor);
printf ("senjata musuh%s%i%sSenjata anda:%s%i%s%ssenjata priest:%s%i\n\n",
"\t", e [j].wh, "\t", "\t", hero.weapon,"\t","\t","\t",priest.weapon);
printf ("[1] serang\n[2] defend\n[3] stats\n[4] lari\n");
}

void battle (int m)
{
int gh;
int data=m;
int victim;
hero.run = 0;
ehp = e [m].hp;
while (ehp > 0 && hero.hp > 0 && (hero.run < 13 || !e [m].run))
{
for (valid = 0; !valid; choice (&n, 4))
{
system ("cls");
status (data);
}
if (n == 1 && hero.hp > 0)
{
damage = damage_calc1(data);
printf ("Anda menyerang musuh sebesar %i damage\n\n", damage);
if ((ehp -= damage) < 1)
{
ehp=0;
printf ("Anda telah membunuh musuh\n");
printf ("Anda mendapatkan: %i gold\n", e [m].gold);
hero.gold += e [m].gold;
hero.hp += 5;
hero.mhp += 5;
}
}
if (n == 2 && hero.hp > 0)
{
printf ("Anda melakukan defense\n\n");
}
status (data);
if(n == 1 && hero.hp > 0){
    printf ("\nAnda menyerang musuh sebesar %i damage\n\n", damage);
} else if(n == 2 && hero.hp > 0){
    printf ("Anda melakukan defense\n\n");
}
gh=n;
if (priest.hp > 0 && (n==1||n==2) && ehp>0){
printf ("[1] serang\n[2] heal hero\n[3] heal priest\n");
for (valid = 0; !valid; choice (&n, 3));
if (n == 1 && hero.hp > 0)
{
damage = damage_calc3(data);
printf ("Priest menyerang musuh sebesar %i damage\n\n", damage);
if ((ehp -= damage) < 1)
{
ehp=0;
printf ("Priest telah membunuh musuh\n");
printf ("Hero mendapatkan: %i gold\n", e [m].gold);
hero.gold += e [m].gold;
hero.hp += 5;
hero.mhp += 5;
}
}
if (n==2 && hero.hp >0){
damage = damage_calc4();
printf ("Priest mengeheal hero sebesar %i\n\n",damage);
hero.hp+=damage;
if (hero.hp>hero.mhp){
    hero.hp=hero.mhp;
}}
if (n==3 && hero.hp >0){
damage = damage_calc4();
printf ("Priest mengeheal dirinya sebesar %i\n\n",damage);
priest.hp+=damage;
if (priest.hp>priest.mhp){
    priest.hp=priest.mhp;
}}
}
if ((gh == 1 ) && ehp > 0)
{
srand(rand()%99);
victim=rand()%3;
if (victim==1 && priest.hp>0){
damage = damage_calc6(data);
printf ("Musuh menyerang priest sebesar %i damage\n", damage);
if ((priest.hp -= damage) < 1) {
        printf ("Priest PINGSAN!\n");
        priest.hp=0;
        }
}   else {
damage=damage_calc2(data);
printf ("Musuh menyerang anda sebesar %i damage\n", damage);
if ((hero.hp -= damage) < 1) printf ("Anda KALAH!\n");
}
}
if ((gh == 2 ) && ehp > 0)
{
srand(rand()%98);
victim=rand()%3;
if (victim==1 && priest.hp>0){
damage = damage_calc6(data);
printf ("Musuh menyerang priest sebesar %i damage\n", damage);
if ((priest.hp -= damage) < 1) {
        printf ("Priest PINGSAN!\n");
        priest.hp=0;
        }}   else {
damage = damage_calc5(data);
printf ("Musuh menyerang anda sebesar %i damage\n", damage);
if ((hero.hp -= damage) < 1) printf ("Anda KALAH!\n");
}}

if (gh == 4 && (hero.run = rand () % 26) > 12 && e [m].run)
printf ("\nAnda berhasil melarikan diri\n");
if (gh == 4 && (hero.run < 13 || !e [m].run)){
printf ("\nAnda gagal melarikan diri\n");
srand(rand()%99);
victim=rand()%3;
if (victim==1 && priest.hp>0){
damage = damage_calc6(data);
printf ("Musuh menyerang priest sebesar %i damage\n", damage);
if ((priest.hp -= damage) < 1) {
        printf ("Priest PINGSAN!\n");
        priest.hp=0;
        }
}   else {
damage=damage_calc2(data);
printf ("Musuh menyerang anda sebesar %i damage\n", damage);
if ((hero.hp -= damage) < 1) printf ("Anda KALAH!\n");
}}
if (gh == 3) printstat ();
enter ();
}}

void heal (int choice)
{
if (hero.gold < 50) printf ("Anda tidak mempunyai gold yang cukup\n");
else{
printf ("HP anda full: %i\n", hero.hp = hero.mhp);
printf ("HP Priest full: %i\n",priest.hp=priest.mhp);
hero.gold -= 50;
printf ("Gold:%i\n",hero.gold);
}
if (n == choice) enter ();
}

void weaponsstore ()
{
for (valid = 0; !valid; choice (&n, 4))
{
system ("cls");
for (i = 0, printf ("Toko Senjata\n"); i < 3; i++)
printf ("[%i] %s%s-- Maksimum Damage: %i%s-- "
"Harga: %i\n", i + 1, w [i].name, "\t",
w [i].damage, "\t", w [i].price);
printf ("\nYang mana yang anda ingin beli?\n");
}
if (hero.gold < w [--n].price)
printf ("Anda tidak punya Gold yang cukup\n\n");
else if (hero.gold >= w [n].price){
printf ("Anda beli yang terbaik: %s\n", w [n].name);
hero.weapon = w [n].damage;
strcpy (hero.wname, w [n].name);
}
printstat();
enter ();
}

int main(){
srand (time (NULL));
intro();
sambutan();
for (valid = 0; !valid; choice (&n, 0)) system ("cls");
next = n;
while (hero.hp > 0) if (hero.hp > 0) (*(p [next - 1].map)) ();

}

void pictmap1(){
printf("\n");
printf (R"EOF(
              .                  .-.    .  _   *     _   .
           *          /   \     ((       _/ \       *    .
         _    .   .--'\/\_ \     `      /    \  *    ___
     *  / \_    _/ ^      \/\'__        /\/\  /\  __/   \ *
       /    \  /    .'   _/  /  \  *' /    \/  \/ .`'\_/\   .
  .   /\/\  /\/ :' __  ^/  ^/    `--./.'  ^  `-.\ _    _:\ _
     /    \/  \  _/  \-' __/.' ^ _   \_   .'\   _/ \ .  __/ \
   /\  .-   `. \/     \ / -.   _/ \ -. `_/   \ /    `._/  ^  \
  /  `-.__ ^   / .-'.--'    . /    `--./ .-'  `-.  `-. `.  -  `.
@/        `.  / /      `-.   /  .-'   / .   .'   \    \  \  .-  \%
@&8jgs@@%% @)&@&(88&@.-_=_-=_-=_-=_-=_.8@% &@&&8(8%@%8)(8@%8 8%@)%
@88:::&(&8&&8:::::%&`.~-_~~-~~_~-~_~-~~=.'@(&%::::%@8&8)::&#@8::::
`::::::8%@@%:::::@%&8:`.=~~-.~~-.~~=..~'8::::::::&@8:::::&8:::::'
 `::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::.'))))EOF");
 printf("\n\n");
}
void map1(){
system ("cls");
printf ("Gunung ini terkenal sangat angker,\n");
printf ("Masyarakat setempat memuja makhluk di sini\ndan memberikan mereka sesajen.\n");
pictmap1();
enter ();
weaponsstore ();
battle (2);
battle (3);
if (hero.hp < 1) return;
system ("cls");
printf ("Anda bertemu seorang healer dan ia mempersiapkan "
"anda untuk menghadapi musuh terakhir.\n");
enter ();
hero.hp = hero.mhp;
priest.hp=priest.mhp;
battle (4);
if (hero.hp < 1) return;
system ("cls");
printf ("Sang makhluk agung telah kalah di Bukaresh, "
"tapi pekerjaan anda belum selesai...\n");
enter ();
hero.hp = 0;
}

void pictmap2(){
printf("\n");
printf(R"EOF(
                            ,@@@@@@@,
       ,,,.   ,@@@@@@/@@,  .oo8888o.
    ,&%%&%&&%,@@@@@/@@@@@@,8888\88/8o
   ,%&\%&&%&&%,@@@\@@@/@@@88\88888/88'
   %&&%&%&/%&&%@@\@@/ /@@@88888\88888'
   %&&%/ %&%%&&@@\ V /@@' `88\8 `/88'
   `&%\ ` /%&'    |.|        \ '|8'
       |o|        | |         | |
       |.|        | |         | |
 \\/ ._\//_/__/  ,\_//__\\/.  \_//__/_
)EOF");
printf("\n\n");
}
void map2(){
for (valid = 0; !valid; choice (&n, 3))
{
system ("cls");
printf ("Hutan benar-benar sangat sunyi, sepertinya tidak ada musuh di sini\n");
printf ("Mau ke mana?\n[1] healer "
"(50 gold)\n[2] Toko senjata\n[3] Kota\n");
pictmap2();
}
if (n == 1) heal (1);
else if (n == 2) weaponsstore ();
else if (n == 3){
next = 4;
return;
}
for (valid = 0; !valid; choice (&n, 0)) system ("cls");
next = n;
}

void pictmap3(){
printf("\n\n");
printf(R"EOF(
                _________....-~    ~-.______
~~~                            ~~~~-----...___________..--------
                                           |   |     |
                                           | |   |  ||
                                           |  |  |   |
                                           |'. .' .`.|
___________________________________________|0oOO0oO0o|____________
 -          -         -       -      -    / '  '. ` ` \    -    -
      --                  --       --   /    '  . `   ` \    --
---            ---          ---       /  '                \ ---
     ----               ----        /       ' ' .    ` `    \  ----
-----         -----         ----- /   '   '        `      `   \
     .-~~-.          ------     /          '    . `     `    `  \
    (_^..^_)-------           /  '    '      '      `
                     --------/     '     '   ')EOF");
printf("\n\n");
}
void map3(){
system ("cls");
printf ("Banyak makhluk-makhluk kecil menyeramkan di sungai,\n"
"makhluk ini terkenal sering mengganggu warga setempat\n");
printf ("Makhluk yang paling besar akan sangat ganas.\n");
pictmap3();
enter ();
battle (0);
battle (1);
if (hero.hp < 1) return;
for (valid = 0; !valid; choice (&n, 0)) system ("cls");
next = n;
}

void pictmap4(){
printf("\n");
printf(R"EOF(
                      .|
                       | |
                       |'|            ._____
               ___    |  |            |.   |' .---"|
       _    .-'   '-. |  |     .--'|  ||   | _|    |
    .-'|  _.|  |    ||   '-__  |   |  |    ||      |
    |' | |.    |    ||       | |   |  |    ||      |
 ___|  '-'     '    ""       '-'   '-.'    '`      |____
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~)EOF");
printf("\n\n");
}
void map4(){
system("cls");
printf("Monster-monster telah menyerang gedung-gedung!\n");
printf("Kekacauan terjadi dimana-mana");
pictmap4();
enter();
for (n = 1; hero.hp > 0 && (n == 1 || n == 3);)
{
srand (rand()%100);
e [5].hp = rand () % 26 + 30;
srand (rand()%100);
e [5].ap = rand () % 26;
srand (rand()%100);
e [5].gold = rand () % 26 + 30;
srand (rand()%100);
e [5].wh = rand () % 26 + 12;
for (battle (5), valid = 0; !valid; choice (&n, 3))
{
system ("cls");
printf ("Anda ingin bertarung lagi?\n");
printf ("[1] Ya\n[2] Tidak\n[3] heal\n");
}
if (n == 3) heal (3);
}
if (hero.hp < 1) return;
for (valid = 0; !valid; choice (&n, 0)) system ("cls");
next = n;
}
